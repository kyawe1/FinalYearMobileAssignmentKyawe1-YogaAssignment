-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: yoga_assignment
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `yoga_classes`
--

DROP TABLE IF EXISTS `yoga_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `yoga_classes` (
  `id` varchar(225) NOT NULL,
  `date` date NOT NULL,
  `teacher_name` text NOT NULL,
  `additional_comments` text,
  `yoga_id` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yoga_classes`
--

LOCK TABLES `yoga_classes` WRITE;
/*!40000 ALTER TABLE `yoga_classes` DISABLE KEYS */;
INSERT INTO `yoga_classes` VALUES ('yogaclss_0cefe2e4-35b6-4a27-9475-ac7a85bfe7b6','2024-10-13','kyawe','vvdfsgdfsgdfsgfdvbfdfgdfsgs','yoga_8608439f-f214-47d1-b287-14f00a2ced60'),('yogaclss_325d14d3-ba25-4531-85fd-0f6dbd6de05b','2024-10-14','fdaf','fdafafafafdfasf','yoga_8608439f-f214-47d1-b287-14f00a2ced60'),('yogaclss_49ab90ef-05bc-49d5-b033-f6d1ba4427eb','2024-10-13','poop','dfafafadsfafaf','yoga_8608439f-f214-47d1-b287-14f00a2ced60'),('yogaclss_4d15c677-5175-4183-8be3-9bc70dd1deb7','2025-10-12','fdasfasffd','gdfsgdsgdsgsds','yoga_8608439f-f214-47d1-b287-14f00a2ced60');
/*!40000 ALTER TABLE `yoga_classes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-02 11:10:25
